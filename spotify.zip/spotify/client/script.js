console.log("welcome");
let audioElement= new Audio('song/1.mp3');

// audioElement.play();
let songIndex=1;
let desc=document.querySelector('.description')
let masterPlay=document.getElementById('masterPlay');
let myProgressBar=document.getElementById('myProgressBar');
let gif=document.getElementById('gif');
let songItems=Array.from(document.getElementsByClassName('songItem'));
let next=document.getElementById('next');
let prev=document.getElementById('prev');
let add=document.querySelector('.songitemcontainer');
let songs =[
    {songName: "aakhon seh batana", filePath: "song/1.mp3",coverPath: "cover/1.jpeg"},
    {songName: "jaan ban gye", filePath: "song/2.mp3",coverPath: "cover/2.jpeg"},
    {songName: "saibo", filePath: "song/3.mp3",coverPath: "cover/3.jpeg"},
    {songName: "tum mile", filePath: "song/4.mp3",coverPath: "cover/4.jpeg"},
    {songName: "tum saath ho", filePath: "song/5.mp3",coverPath: "cover/5.jpeg"},
    {songName: "care ni krda", filePath: "song/6.mp3",coverPath: "cover/6.jpeg"},
    {songName: "mast magan", filePath: "song/7.mp3",coverPath: "cover/7.jpeg"},
    {songName: "gallan goodiyan", filePath: "song/8.mp3",coverPath: "cover/8.jpeg"},
    {songName: "tose naina", filePath: "song/9.mp3",coverPath: "cover/9.jpeg"},
    {songName: "tose naina X let me down slowly", filePath: "song/10.mp3",coverPath: "cover/10.jpeg"},
    {songName: "hum nashe meh toh nhi", filePath: "song/11.mp3",coverPath: "cover/11.jpeg"},
    

]
desc.innerHTML=`
  <img src="cover/${1}.jpeg" alt="1">
  <p class="pos">[${songs[0].songName}]<p>`
//Listen to events
//handle play pausse click
next.addEventListener('click',()=>{
    audioElement.pause();
    if(songIndex<11)
    songIndex++;
    else
    songIndex=1;
    audioElement.src=`song/${songIndex}.mp3`;
    audioElement.currentTime=0;
  audioElement.play();
  gif.style.opacity=1;
  masterPlay.classList.remove('fa-circle-play');
  masterPlay.classList.add('fa-circle-pause');
  desc.innerHTML=`
  <img src="cover/${songIndex}.jpeg" alt="1">
  <p class="pos">[${songs[songIndex-1].songName}]<p>`

})
prev.addEventListener('click',()=>{
    audioElement.pause();
    if(songIndex>1)
    songIndex--;
    else
    songIndex=11;
    audioElement.src=`song/${songIndex}.mp3`;
    audioElement.currentTime=0;
  audioElement.play();
  gif.style.opacity=1;
  masterPlay.classList.remove('fa-circle-play');
  masterPlay.classList.add('fa-circle-pause');
  desc.innerHTML=`
  <img src="cover/${songIndex}.jpeg" alt="1">
  <p class="pos">[${songs[songIndex-1].songName}]<p>`

})
masterPlay.addEventListener('click',()=>{
    if(audioElement.paused || audioElement.currentTime<=0){
        audioElement.play();
        masterPlay.classList.remove('fa-circle-play');
        masterPlay.classList.add('fa-circle-pause');
         gif.style.opacity=1;
    }
    else
    {
        audioElement.pause();
        masterPlay.classList.remove('fa-circle-pause');
        masterPlay.classList.add('fa-circle-play');
        gif.style.opacity=0;
    }
})
audioElement.addEventListener('timeupdate',()=>
{
    
    //update seekbar
    progress = parseFloat((audioElement.currentTime/audioElement.duration)*100);
    
    myProgressBar.value = progress;
})
myProgressBar.addEventListener('change', ()=>{
    audioElement.currentTime=myProgressBar.value * audioElement.duration/100;
})
// songItems.forEach((element,i)=>{
    
// element.getElementsByTagName("img")[0].src=songs[i].coverPath;
// element.getElementsByClassName("songname")[0].innerText=songs[i].songName;


// })
songs.forEach((element,i)=>{
    add.innerHTML+=`<div class="songItem">
    <img src="${element.coverPath}" alt="1">
    <span class="songname">${element.songName}</span>
    <span class="songlistplay">
        <spane class="tim">03:43
    </span><i class="cur fa-solid fa-2x fa-circle-play" id="${i}"></i></span>
    </div>`;
})
// let cross=document.getElementById('cross');
// cross.addEventListener('click',()=>{
//     document.getElementById(
//         'searchWrapper').value = '';
// })
let filter = (document.getElementById('searchWrapper'));
let pd;let k;
function searchFun(){
    add.innerHTML=``;
    console.log(filter.value);
    k=0;
songs.forEach((element,i)=>{
    if((element.songName).includes(filter.value))
   { k++;
    add.innerHTML+=`<div class="songItem">
    <img src="${element.coverPath}" alt="1">
    <span class="songname">${element.songName}</span>
    <span class="songlistplay">
        <spane class="tim">03:42
    </span><i class="cur fa-solid fa-2x fa-circle-play" id="${i}"></i></span>
    </div>`;}
})
if(k==0)
{
    add.innerHTML=`<h1>Nothing Found<h1>`;
}
}

const makeAllPlays=()=>{
    Array.from(document.getElementsByClassName('cur')).forEach((element)=>
    {
        element.classList.remove('fa-circle-pause');

        element.classList.add('fa-circle-play');
    })
}
let it=0
Array.from(document.getElementsByClassName('cur')).forEach((element)=>{
element.addEventListener('click',(e)=>{
  makeAllPlays();
  index=parseInt(e.target.id);
  songIndex=index+1;
  e.target.classList.add('fa-circle-pause');
  e.target.classList.remove('fa-circle-play');
  audioElement.src=`song/${index+1}.mp3`;
  audioElement.currentTime=0;
  audioElement.play();
  gif.style.opacity=1;
  masterPlay.classList.remove('fa-circle-play');
  masterPlay.classList.add('fa-circle-pause');
  desc.innerHTML=`
  <img src="cover/${index+1}.jpeg" alt="1">
  <p class="pos">[${songs[index].songName}]<p>`
  
})
})

