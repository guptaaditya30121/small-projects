const express = require('express');
const mongoose = require('mongoose');
const cors  = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const url = "mongodb+srv://aditya:19172621@cluster0.wywcrgi.mongodb.net/song_app?retryWrites=true&w=majority";

mongoose.connect(url).then(()=>{
    console.log("connected to db");
}).catch(()=>{
    console.log("Error");
})




app.listen(3001 , ()=>{
    console.log("server is listening");
})