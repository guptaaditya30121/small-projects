// Give the service worker access to Firebase Messaging.
// Note that you can only use Firebase Messaging here. Other Firebase libraries
// are not available in the service worker.
importScripts('https://www.gstatic.com/firebasejs/8.10.1/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.10.1/firebase-messaging.js');

// Initialize the Firebase app in the service worker by passing in
// your app's Firebase config object.
// https://firebase.google.com/docs/web/setup#config-object
firebase.initializeApp({
    apiKey: "AIzaSyA6i8M5mSO6Qbj4nutP1OdrjfIKzbvGAsQ",
    authDomain: "hello-notification-4eab4.firebaseapp.com",
    projectId: "hello-notification-4eab4",
    storageBucket: "hello-notification-4eab4.appspot.com",
    messagingSenderId: "894181541764",
    appId: "1:894181541764:web:efbed4fbbc9f4afa8dbfd1",
    measurementId: "G-FFMEWBZQZ5"
});

// Retrieve an instance of Firebase Messaging so that it can handle background
// messages.
const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
    console.log(
      '[firebase-messaging-sw.js] Received background message ',
      payload.notification.body
    );
    // Customize notification here
    const notificationTitle = payload.notification.title;
    const notificationOptions = {
      body: payload.notification.body,
      icon: '/firebase-logo.png'
    };
  
    self.registration.showNotification(notificationTitle, notificationOptions);
  });