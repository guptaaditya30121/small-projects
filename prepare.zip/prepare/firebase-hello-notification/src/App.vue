<script setup>
import HelloWorld from './components/HelloWorld.vue'
import { initializeApp } from "firebase/app";
import { getMessaging, getToken, onMessage } from "firebase/messaging";
import { ref, onMounted , computed} from 'vue';
 import { toast } from 'vue3-toastify';
const firebaseConfig = {
  apiKey: "AIzaSyA6i8M5mSO6Qbj4nutP1OdrjfIKzbvGAsQ",
  authDomain: "hello-notification-4eab4.firebaseapp.com",
  projectId: "hello-notification-4eab4",
  storageBucket: "hello-notification-4eab4.appspot.com",
  messagingSenderId: "894181541764",
  appId: "1:894181541764:web:efbed4fbbc9f4afa8dbfd1",
  measurementId: "G-FFMEWBZQZ5"
};

// Initialize Firebase
// const app = initializeApp(firebaseConfig);
// Get registration token. Initially this makes a network call, once retrieved
// subsequent calls to getToken will return from cache.
const messaging = getMessaging();
const token = ref(null);

// const toast = useToast(); 

onMessage(messaging, (payload) => {
  const notification = {
    title: payload.notification.title,
    body: payload.notification.body
  };
  console.log(notification);
  toast('Notification received', { position: 'top-right', duration: 5000 });
  new Notification(notification.title, notification);
  // ...
});

onMounted(async () => {
  try {
    const currentToken = await getToken(messaging, { vapidKey: 'BPvAIQFlWGN1CPBcXmh3OzS0slv_wo2VEp5lkbv6su1Vm9OlAuMMM3ljdVv5sehiFAenkvpZeMW6wEEyKuEupkA' });
    if (currentToken) {
      console.log("Token is:", currentToken);
      token.value = currentToken;
    } else {
      console.log('No registration token available. Request permission to generate one.');
    }
  } catch (err) {
    console.log('An error occurred while retrieving token. ', err);
  }
});

const computedToken = computed(() => {
  return token.value;
});




</script>

<template>
  <div>
    <!-- <a href="https://vitejs.dev" target="_blank">
      <img src="/vite.svg" class="logo" alt="Vite logo" />
    </a> -->
    <!-- <a href="https://vuejs.org/" target="_blank">
      <img src="./assets/vue.svg" class="logo vue" alt="Vue logo" />
    </a> -->
    <div>
      Token: {{ computedToken }}
    </div>
  </div>
  <HelloWorld msg="Vite + Vue" />
</template>

<style scoped>
.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
  transition: filter 300ms;
}
.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}
.logo.vue:hover {
  filter: drop-shadow(0 0 2em #42b883aa);
}
</style>
