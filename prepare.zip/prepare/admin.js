// full project with vue: https://github.com/benixal/vue-firebase-push-notification

var admin = require("firebase-admin");

var serviceAccount = require("./hello-notification-4eab4-firebase-adminsdk-96ul4-1145782344.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});
// This registration token comes from the client FCM SDKs.
const registrationToken = 'eW-HyY3Kw3cseeZ9hqEASq:APA91bHsCbR7sPo6mzKSqQxNiu3LzisWIinLvHDdWi-M0K0jJ0FQwLqiOXWSpqlUHQm0qCbB0-i_voojJ5OXOF3Jccv_MomvRULZHgrSiW9ZMlBVQHnejOLyTJPv5PvZtfAWdTd202bO';

const message = {
   notification: {
    title: "I am Admin",
    body: "Hi client"
   },
   webpush: {
    fcmOptions: {
      link: '/?breakingnews'
    }
  },
  token: registrationToken
};

// Send a message to the device corresponding to the provided
// registration token.
admin.messaging().send(message)
  .then((response) => {
    // Response is a message ID string.
    console.log('Successfully sent message:', response);
  })
  .catch((error) => {
    console.log('Error sending message:', error);
  });