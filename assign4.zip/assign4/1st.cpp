#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int t0 = 0; // this saves last dequeued time;
class http_request{
    public:
        int req_id;
        int web_id;
        int proc_time;
        http_request(int req_id,int web_id,int proc_time)
        {
            this->req_id = req_id;
            this->web_id = web_id;
            this->proc_time = proc_time;
        }
};
class Website{
    public:
        int web_id;
        int owner_id;
        double bandwidth;
        double pp;
        queue<http_request> requests;
        Website(int web_id,int owner_id,double bandwidth,double pp)
        {
            this->web_id = web_id;
            this->owner_id = owner_id;
            this->bandwidth = bandwidth;
            this->pp = pp;
        }
};
class load_balancer{
    private:
        vector<Website> active_websites;
        double total_bandwidth; 
    public:
        load_balancer(int x)
        {
            total_bandwidth = 0;
            active_websites.clear();
        }
        void add_website(int web_id,int owner_id,double bandwidth,double pp)
        {
            active_websites.push_back(Website(web_id,owner_id,bandwidth,pp));
            total_bandwidth += bandwidth;
        }
        void enqueue_request(http_request hr , int arr_time)
        {
            for(int i = 0;i < active_websites.size();i++)
            {
                if(active_websites[i].web_id == hr.web_id)
                {
                    active_websites[i].requests.push(hr);
                    cout<<"Successfully pushed\n";
                }
            }
        }
        void check()
        {
            for(int i = 0;i < active_websites.size();i++)
            {
                cout<<active_websites[i].requests.size()<<endl;
            }
        }
        void print(http_request hr)
        {
            cout<<"request Id : "<<hr.req_id<<endl;
        }
        void dequeue_request()
        {
            
        }
        
};
load_balancer *lb;
void input()
{
    while(1)
    {
        cout<<"Press 1 to Enter the http packet , or Press 0 to exit\n";
        int x;
        cin>>x;
        if(x==1)
        {
            cout<<"Enter req_id , web_id, proc_time";
            int req_id;
            int web_id;
            int proc_time;
            int arr_time;
            cin>>req_id>>web_id>>proc_time>>arr_time;
            http_request hr = http_request(req_id,web_id,proc_time);
            lb->enqueue_request(hr , arr_time);   
        }
        else
        {
            break;
        }
        
    }
}
void takeout()
{
    
}
int main()
{
ios_base::sync_with_stdio(false);cin.tie(NULL);
    lb = new load_balancer(0);
    cout<<"Enter no. of websites";
    int n;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cout<<"Enter web_id owner_id bandwidth processing_power";
        int web_id;
        int owner_id;
        int bandwidth;
        int proc_pow;
        cin>>web_id>>owner_id>>bandwidth>>proc_pow;
        lb->add_website(web_id,owner_id,bandwidth,proc_pow);
    }
    std::thread th1(input);

    std::thread th2(takeout);

return 0;
}
