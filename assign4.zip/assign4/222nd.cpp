#include<bits/stdc++.h>
#include<unistd.h>
#include <thread>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <sys/sem.h>
#include<string.h>
using namespace std;
#define N 10000
vector<queue<int>>q;
// union semun
// {
//     int val;              /* used for SETVAL only */
//     struct semid_ds *buf; /* for IPC_STAT and IPC_SET */
//     int *array;           /* used for GETALL and SETALL */
// };

void sem_signal(int sem_id, int sem_num)
{
    struct sembuf sem_op;
    sem_op.sem_num = 0;
    sem_op.sem_op = 1;
    sem_op.sem_flg = 0;
    semop(sem_id, &sem_op, 1);
}

void sem_wait(int sem_id, int sem_num)
{
    struct sembuf sem_op;
    sem_op.sem_num = 0;
    sem_op.sem_op = -1;
    sem_op.sem_flg = 0;
    semop(sem_id, &sem_op, 1);
}


void incoming(vector<int> semid , double alpha)
{
    std::default_random_engine generator;
    std::exponential_distribution<double> distribution(alpha);
    int s=semid.size();
    while(1)
    {
        double time = distribution(generator);
        sleep(time);
        int min_sz=1e9;
        int ind=-1;
        for(int i=0;i<s;i++){
            sem_wait(semid[i],1);
            min_sz=min(min_sz,q[i].size());
            if(min_sz==q[i].size())ind=i;
            sem_signal()
        }
        sem_wait(semid , 1);
        if(q.size()<N)
        {
            q.push(1);
            cout<<"enqueued "<<q.size()<<endl;
        }
        sem_signal(semid , 1);
    }
    return;
}
void outgoing(int semid[] , double beta , int num, int s)
{
    std::default_random_engine generator;
    std::exponential_distribution<double> distribution(beta);
    while(1)
    {
        double time = distribution(generator);
        sleep(time);
        sem_wait(semid[i] , 1);
        if(q.size())
        {q.pop();
        cout<<num<<" dequeued "<<q.size()<<endl;}
        sem_signal(semid , 1);
    }
    return;
}
int main()
{
    ios_base::sync_with_stdio(false);cin.tie(NULL);
    srand(time(NULL));
    key_t key;
    key = ftok("check.cpp" , 1);
    double alpha , beta;
    cout<<"Enter arrival rate and service rate\n";
    cin>>alpha>>beta;
    int s;
    cout<<"Enter no. of servers\n";
    cin>>s;
    q.resize(s);
    vector<int>semid(s);

    for(int i=0;i<s;i++){
        semid[i]=semget(key+i,1,IPC_CREAT | 0644);
        if (semid[i] == -1) {
            perror("semget");
            exit(1);
        }
        union semun sem_arg;
        sem_arg.val = 1;
        semctl(semid[i], 0, SETVAL, sem_arg);
    }
    

    std::thread t( incoming , semid , alpha, s);

    std::vector<std::thread> OutThreadVector;

    for(int i=0;i<s;i++)
    {
        OutThreadVector.push_back(std::thread(outgoing,semid , beta , i,s));
    }

    t.join();

    for(auto& t2: OutThreadVector)
    {
        t2.join();

    }
    
    return 0; 
}