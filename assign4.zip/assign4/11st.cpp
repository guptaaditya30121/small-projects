#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int t0 = 0; // this saves last dequeued time;
class http_request{
    public:
        int req_id;
        int web_id;
        int proc_time;
        http_request(int req_id,int web_id,int proc_time)
        {
            this->req_id = req_id;
            this->web_id = web_id;
            this->proc_time = proc_time;
        }
};
class Website{
    public:
        int web_id;
        int owner_id;
        double bandwidth;
        queue<http_request> requests;
        Website(int web_id,int owner_id,double bandwidth)
        {
            this->web_id = web_id;
            this->owner_id = owner_id;
            this->bandwidth = bandwidth;
        }
};
class load_balancer{
    private:
        vector<Website> active_websites;
        double total_bandwidth; 
    public:
        load_balancer(int x)
        {
            total_bandwidth = 0;
            active_websites.clear();
        }
        void add_website(int web_id,int owner_id,double bandwidth,int pp)
        {
            active_websites.push_back(Website(web_id,owner_id,bandwidth));
            total_bandwidth += bandwidth;
        }
        void enqueue_request(http_request hr , int arr_time)
        {
            for(int i = 0;i < active_websites.size();i++)
            {
                if(active_websites[i].web_id == hr.web_id)
                {
                    if(active_websites[i].requests.size()==0)
                    {
                        double weight = active_websites[i].bandwidth; 
                        hr.proc_time  -= (t0 - arr_time)*weight;
                    }
                    active_websites[i].requests.push(hr);
                    cout<<"Successfully pushed\n";
                }
            }
        }
        void check()
        {
            for(int i = 0;i < active_websites.size();i++)
            {
                cout<<active_websites[i].requests.size()<<endl;
            }
        }
        void print(http_request hr)
        {
            cout<<"request Id : "<<hr.req_id<<endl;
        }
        void dequeue_request()
        {
            double time = 1e9;
            
            for(int i = 0;i < active_websites.size();i++)
            {
                
                if(active_websites[i].requests.size()==0) 
                continue;

                double weight = active_websites[i].bandwidth; 
                http_request hr = active_websites[i].requests.front();
                time = min(time ,(hr.proc_time*1.0)/weight);
            }
            if(time == 1e9)
            {
                cout<<"Nothing to dequeue\n";
            }
            for(int i = 0;i < active_websites.size();i++)
            {
                if(active_websites[i].requests.size()==0) 
                continue;

                double weight = active_websites[i].bandwidth;
                if((active_websites[i].requests.front().proc_time * 1.0)/weight == time)
                {
                    print(active_websites[i].requests.front());
                    active_websites[i].requests.pop();
                }
                else
                {
                    active_websites[i].requests.front().proc_time -= weight*time;
                }
            }
        }
        
};
int main()
{
ios_base::sync_with_stdio(false);cin.tie(NULL);
    load_balancer lb(0);
    while(1)
    {
        int a;
        cout<<"Enter 1 for adding website,2 for enquing request,3 for dequeuing,4 for exit => ";
        cin>>a;
        if(a==1)
        {
            int web_id;
            int owner_id;
            double bandwidth;
            cin>>web_id>>owner_id>>bandwidth;
            lb.add_website(web_id,owner_id,bandwidth,0);
        }
        else if(a==2)
        {
            int req_id;
            int web_id;
            int proc_time;
            int arr_time;
            cin>>req_id>>web_id>>proc_time>>arr_time;
            http_request hr = http_request(req_id,web_id,proc_time);
            lb.enqueue_request(hr , arr_time);
        }
        else if(a==3)
        {
            lb.dequeue_request();
        }
        else if(a==5)
        {
            lb.check();
        }
        else
        {
            break;
        }
    }
return 0;
}
