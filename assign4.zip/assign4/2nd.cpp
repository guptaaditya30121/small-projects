#include<bits/stdc++.h>
#include<unistd.h>
#include <thread>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <sys/sem.h>
#include<string.h>
using namespace std;

queue<time_t> q;
int cnt = 0;
double avg_size_queue = 0;
int no_of_passengers = 0;
double avg_wt = 0;
// union semun
// {
//     int val;              /* used for SETVAL only */
//     struct semid_ds *buf; /* for IPC_STAT and IPC_SET */
//     int *array;           /* used for GETALL and SETALL */
// };

void sem_signal(int sem_id, int sem_num)
{
    struct sembuf sem_op;
    sem_op.sem_num = 0;
    sem_op.sem_op = 1;
    sem_op.sem_flg = 0;
    semop(sem_id, &sem_op, 1);
}

void sem_wait(int sem_id, int sem_num)
{
    struct sembuf sem_op;
    sem_op.sem_num = 0;
    sem_op.sem_op = -1;
    sem_op.sem_flg = 0;
    semop(sem_id, &sem_op, 1);
}


void incoming(int semid , double alpha)
{
    
    std::default_random_engine generator;
    std::exponential_distribution<double> distribution(alpha);
    while(1)
    {
        if(cnt >= 4000000)
        {
            break;
        }
        double tme = distribution(generator);
        sleep(tme);
        sem_wait(semid , 1);
        auto start = std::chrono::system_clock::now();
        q.push(time(NULL));
        no_of_passengers++;
        cout<<"enqueued "<<q.size()<<endl;
        avg_size_queue+= q.size();
        sem_signal(semid , 1);
    }
    return;
}
void outgoing(int semid , double beta)
{
    std::default_random_engine generator;
    std::exponential_distribution<double> distribution(beta);
    while(1)
    {
        if(cnt >= 4000000)
        {
            break;
        }
        double tme = distribution(generator);
        sleep(tme);
        sem_wait(semid , 1);
        if(q.size())
        {
            time_t temp = q.front();
            avg_wt += time(NULL) - temp;
            q.pop();
            cout<<"dequeued "<<q.size()<<endl;
        }
        avg_size_queue+= q.size();
        sem_signal(semid , 1);
    }
    return;
}
void calc()
{
    while(1)
    {
        avg_size_queue += q.size();
        usleep(10);
        if(cnt >= 4000000)
        {
            break;
        }
        else
        {
            cnt++;
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(false);cin.tie(NULL);
    srand(time(NULL));
    while(!q.empty())
    {
        q.pop();
    }
    key_t key;
    key = ftok("check.cpp" , 1);
    int semid;
    semid = semget(key, 1, IPC_CREAT | 0644);   
    if (semid == -1) {
        perror("semget");
        exit(1);
    }
    union semun sem_arg;
    sem_arg.val = 1;
    semctl(semid, 0, SETVAL, sem_arg);
    double alpha , beta;
    cout<<"Enter arrival rate and service rate\n";
    cin>>alpha>>beta;

    std::thread t( incoming , semid , alpha );
    std::thread t2( outgoing , semid , beta);
    std::thread t3( calc );
    t.join();
    t2.join();
    t3.join();

    avg_size_queue = avg_size_queue / cnt;
    cout<<avg_size_queue<<endl;
    cout<<avg_wt/no_of_passengers<<endl;
    return 0; 
}