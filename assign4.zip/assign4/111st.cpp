#include<bits/stdc++.h>
#include<iostream>
using namespace std;

class http_request{
    public:
        int req_id;
        int web_id;
        int proc_time;
        int arr_time;
        http_request(int req_id,int web_id,int proc_time,int arr_time)
        {
            this->req_id = req_id;
            this->web_id = web_id;
            this->proc_time = proc_time;
            this->arr_time=arr_time;
        }
};
class Website{
    public:
        int web_id;
        int owner_id;
        int bandwidth;
        int pp;
        queue<http_request> requests;
        Website(int web_id,int owner_id,int bandwidth,int pp)
        {
            this->web_id = web_id;
            this->owner_id = owner_id;
            this->bandwidth = bandwidth;
            this->pp = pp;
        }
};
class load_balancer{
    private:
        vector<Website> active_websites;
        set<pair<double,http_request> > st;
        int temp;
    public:
        load_balancer(int x)
        {
            active_websites.clear();
            st.clear();
            temp = 1e9;
        }
        void add_website(int web_id,int owner_id,int bandwidth,int pp)
        {
            active_websites.push_back(Website(web_id,owner_id,bandwidth,pp));
            temp = min(temp , bandwidth*pp);
        }
        void enqueue_request(http_request hr , int arr_time)
        {
            for(int i = 0;i < active_websites.size();i++)
            {
                if(active_websites[i].web_id == hr.web_id)
                {
                    active_websites[i].requests.push(hr);
                    cout<<"Successfully pushed\n";
                }
            }
        }
        void check()
        {
            for(int i = 0;i < active_websites.size();i++)
            {
                cout<<active_websites[i].requests.size()<<endl;
            }
        }
        void print(http_request hr)
        {
            cout<<"req processed :"<<endl;
            cout<<"web Id : "<<hr.web_id<<endl;
            cout<<"request Id : "<<hr.req_id<<endl;
        }
        void calculate()
        {
            for(int i=0;i< active_websites.size();i++)
            {
                queue<http_request> q = active_websites[i].requests;
                double fp = 0;
                while(!q.empty())
                {
                    http_request hr = q.front();
                    q.pop();
                    double w = (active_websites[i].bandwidth * active_websites[i].pp * 1.0)/temp;
                    double a1 = hr.arr_time;
                    double p1 = hr.proc_time;
                    double f;
                    if(a1>=fp)
                    f = a1 + p1/w ;
                    else
                    f = fp + p1/w ;

                    fp = f;
                    st.insert({fp , hr});
                } 
            }
        }
        void dequeue_request()
        {
            print((*st.begin()).second);
            st.erase(st.begin());
        }
        
};
int main()
{
ios_base::sync_with_stdio(false);cin.tie(NULL);
    load_balancer lb(0);
    
    cout<<"Enter no. of websites";
    int n;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cout<<"Enter web_id owner_id bandwidth processing_power";
        int web_id;
        int owner_id;
        int bandwidth;
        int proc_pow;
        cin>>web_id>>owner_id>>bandwidth>>proc_pow;
        lb.add_website(web_id,owner_id,bandwidth,proc_pow);
    }

    cout<<"Enter no. of enqueue requests";
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cout<<"Enter req_id , web_id, proc_time";
        int req_id;
        int web_id;
        int proc_time;
        int arr_time;
        cin>>req_id>>web_id>>proc_time>>arr_time;
        http_request hr = http_request(req_id,web_id,proc_time,arr_time);
        lb.enqueue_request(hr , arr_time);  
    }

    lb.calculate();

    while(1)
    {
        int x;
        cout<<"press Enter to dequeue";
        cin>>x;
        lb.dequeue_request();
    }


return 0;
}
