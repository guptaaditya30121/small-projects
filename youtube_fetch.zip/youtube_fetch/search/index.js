require('dotenv').config();
const { google } = require('googleapis');
const natural = require('natural');

const tokenizer = new natural.WordTokenizer();
const stopWords = require('natural').stopwords;
const moment = require('moment');

function toSeconds(duration) {
  let hours = 0, minutes = 0, seconds = 0;

  const match = duration.match(/PT(\d+H)?(\d+M)?(\d+S)?/);

  if (match) {
    if (match[1]) hours = parseInt(match[1]);
    if (match[2]) minutes = parseInt(match[2]);
    if (match[3]) seconds = parseInt(match[3]);
  }

  return (hours * 3600) + (minutes * 60) + seconds;
}

function countWords(text) {
    const wordsFrequency = {};
  
    const words = text.toLowerCase().split(/\s+/);
  
    words.forEach(word => {
      if (word.length > 2 && !['will','among','com','www','https','youtube','official','online','videos','songs'].includes(word)) {
        if (wordsFrequency[word]) {
          wordsFrequency[word]++;
        } else {
          wordsFrequency[word] = 1;
        }
      }
    });
  
    return wordsFrequency;
}

function countHashWords(text) {
    const wordsFrequency = {};
  
    const words = text.toLowerCase().split(/\s+/);
  
    words.forEach(word => {
      if (word[0] == '#') {
        if (wordsFrequency[word]) {
          wordsFrequency[word]++;
        } else {
          wordsFrequency[word] = 1;
        }
      }
    });
  
    return wordsFrequency;
}

function cleanStopWords(text) {
  const tokens = tokenizer.tokenize(text.toLowerCase());
  return tokens.filter(token => !stopWords.includes(token));
}

async function searchAndFetchVideos() {
  try {
    const youtube = google.youtube('v3');
    let totalShortVideos = 0;
    let nextPageToken = '';
        const titleWordsFrequency = {};
      const descriptionWordsFrequency = {};
      const titleHashWordsFrequency = {};
      const descriptionHashWordsFrequency = {};
    while (totalShortVideos < 100) {
      const threeMonthsAgo = moment().subtract(3, 'months').format('YYYY-MM-DDTHH:mm:ssZ');
      const searchResponse = await youtube.search.list({
        key: process.env.YOUTUBE_TOKEN,
        part: 'snippet',
        maxResults: 1000,
        order: 'viewCount',
        publishedAfter: threeMonthsAgo,
        q: 'dalgona',
        pageToken: nextPageToken,
      });

      const videoIds = searchResponse.data.items.map(item => item.id.videoId);

      const videoResponse = await youtube.videos.list({
        key: process.env.YOUTUBE_TOKEN,
        part: 'snippet,contentDetails,statistics',
        id: videoIds.join(','),
      });

      const videosData = videoResponse.data.items;

      

      videosData.forEach(videoData => {
        const durationInSeconds = toSeconds(videoData.contentDetails.duration);

        if (durationInSeconds < 60) {
          const title = videoData.snippet.title;
          const description = videoData.snippet.description;

          const titleHashWords = countHashWords(title);
          const descriptionHashWords = countHashWords(description);
          Object.assign(titleHashWordsFrequency, titleHashWords);
          Object.assign(descriptionHashWordsFrequency, descriptionHashWords);

          const cleanTitle = cleanStopWords(title).join(' ');
          const cleanDescription = cleanStopWords(description).join(' ');
          const titleWords = countWords(cleanTitle);
          Object.assign(titleWordsFrequency, titleWords);
          const descriptionWords = countWords(cleanDescription);
          Object.assign(descriptionWordsFrequency, descriptionWords);
          console.log("title: " + cleanTitle);
          console.log("description: " + cleanDescription);
          console.log("duration: " + durationInSeconds);
          console.log("---------------------------------------------------------");
          totalShortVideos++;
        }
      });

      nextPageToken = searchResponse.data.nextPageToken;
      if (!nextPageToken) {
        break;
      }
    }
    const sortedTitleWords = Object.keys(titleWordsFrequency).sort((a, b) => titleWordsFrequency[b] - titleWordsFrequency[a]);
    const topTitleWords = sortedTitleWords.slice(0, 10); // Adjust as needed
    console.log("Top 10 Most Used Words in Titles:");
    topTitleWords.forEach(word => {
      console.log(`${word}: ${titleWordsFrequency[word]} times`);
    });

    const sortedTitleHashWords = Object.keys(titleHashWordsFrequency).sort((a, b) => titleHashWordsFrequency[b] - titleHashWordsFrequency[a]);
    const topTitleHashWords = sortedTitleHashWords.slice(0, 10); // Adjust as needed
    console.log("Top 10 Most Used Words in TitleHashs:");
    topTitleHashWords.forEach(word => {
      console.log(`${word}: ${titleHashWordsFrequency[word]} times`);
    });
   
    const sortedDescriptionWords = Object.keys(descriptionWordsFrequency).sort((a, b) => descriptionWordsFrequency[b] - descriptionWordsFrequency[a]);
    const topDescriptionWords = sortedDescriptionWords.slice(0, 10); // Adjust as needed
    console.log("Top 10 Most Used Words in Descriptions:");
    topDescriptionWords.forEach(word => {
      console.log(`${word}: ${descriptionWordsFrequency[word]} times`);
    });

    const sortedDescriptionHashWords = Object.keys(descriptionHashWordsFrequency).sort((a, b) => descriptionHashWordsFrequency[b] - descriptionHashWordsFrequency[a]);
    const topDescriptionHashWords = sortedDescriptionHashWords.slice(0, 10); // Adjust as needed
    console.log("Top 10 Most Used Words in DescriptionHashs:");
    topDescriptionHashWords.forEach(word => {
      console.log(`${word}: ${descriptionHashWordsFrequency[word]} times`);
    });
  } catch (err) {
    console.error('Error:', err);
  }
}

searchAndFetchVideos();
