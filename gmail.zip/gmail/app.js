'use strict';
const express = require('express');
const app = express();
const fs = require('fs');
const { google } = require('googleapis');
const { OAuth2Client } = require('google-auth-library');
const cors = require('cors'); // Import the cors package
const cron = require('node-cron');
const SCOPES = ['https://www.googleapis.com/auth/gmail.readonly'];
const TOKEN_PATH = 'token.json';
const USERS_JSON_PATH = 'users.json';
const request = require('request');

app.use(cors());
async function authorize(credentials, receivedData) {
  const { client_secret, client_id, redirect_uris } = credentials.installed;
  const oAuth2Client = new OAuth2Client(client_id, client_secret, redirect_uris[0]);

  return new Promise((resolve, reject) => {
    fs.readFile(TOKEN_PATH, (err, token) => {
      if (!err) {
        // Token file exists, set credentials and resolve with existing client
        oAuth2Client.setCredentials(JSON.parse(token));
        resolve(oAuth2Client);
        return;
      }

      // Token file doesn't exist, obtain new token
      oAuth2Client.getToken(receivedData, (err, token) => {
        if (err) {
          reject(err);
          return;
        }
        console.log("hello");
        oAuth2Client.setCredentials(token);
        fs.writeFileSync(TOKEN_PATH, JSON.stringify(token));
        resolve(oAuth2Client);
      });
    });
  });
}

async function listEmails(auth) {
  const gmail = google.gmail({ version: 'v1', auth });
  const response = await gmail.users.messages.list({
    userId: 'me',
  });

  const messages = response.data.messages;
  const formattedMessages = [];

  if (messages && messages.length) {
    for (const message of messages) {
    
      const email = await gmail.users.messages.get({ userId: 'me', id: message.id, format: 'full' });
      //console.log(email);
      const headers = email.data.payload.headers;
      let from = '';
      let subject = '';
      let content = '';

      for (const header of headers) {
        if (header.name.toLowerCase() === 'from') {
          from = header.value;
        }
        if (header.name.toLowerCase() === 'subject') {
          subject = header.value;
        }
      }

      if (email.data.payload.parts && email.data.payload.parts[0].body.data) {
        content = Buffer.from(email.data.payload.parts[0].body.data, 'base64').toString();
      }
      
      formattedMessages.push({
        subject: subject,
        from: from,
        content: content,
        id: message.id,
        historyid: email.data.historyId,
      });
    }
    //formattedMessages.reverse();
  } else {
    console.log('No emails found.');
  }

  return formattedMessages;
}

app.get('/api/messages', async (req, res) => {
  try {
    const receivedData = req.query.data;
    console.log(receivedData);
    const credentials = JSON.parse(fs.readFileSync('credentials.json'));
    const auth = await authorize(credentials , receivedData);
    console.log(auth);
    const messages = await listEmails(auth);
    messages.reverse();
    const usersData = JSON.parse(fs.readFileSync(USERS_JSON_PATH));
    const user = usersData.users[0];
    user.messages = messages;

    fs.writeFileSync(USERS_JSON_PATH, JSON.stringify(usersData, null, 2));
    res.json(messages);
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ error: 'An error occurred' });
  }
});
//Code related to syncing

async function authorizesync(credentials, token) {
  const { client_secret, client_id, redirect_uris } = credentials.installed;
  const oAuth2Client = new OAuth2Client(client_id, client_secret, redirect_uris[0]);

  oAuth2Client.setCredentials(token);
  
  return oAuth2Client;
}

async function listEmailssync(auth, startHistoryId) {
  const gmail = google.gmail({ version: 'v1', auth });

  const response = await gmail.users.history.list({
    userId: 'me',
    startHistoryId: startHistoryId,
  });

  const messages = [];

  if (response.data.history) {
    for (const history of response.data.history) {
      if(history.messagesAdded){
      for (const messageChange of history.messagesAdded) {
        const message = await gmail.users.messages.get({
          userId: 'me',
          id: messageChange.message.id,
          format: 'full', // Ensure you get the full message data
        });

        const headers = message.data.payload.headers;
        let subject = '';
        let from = '';
        let to = '';

        // Extract subject, from, and to from headers
        for (const header of headers) {
          if (header.name.toLowerCase() === 'subject') {
            subject = header.value;
          }
          if (header.name.toLowerCase() === 'from') {
            from = header.value;
          }
          if (header.name.toLowerCase() === 'to') {
            to = header.value;
          }
        }

        messages.push({
          id: message.data.id,
          historyid: message.data.historyId,
          subject: subject,
          from: from,
          to: to,
        });
      }
    }
    }
  }

  return messages;
}











async function syncEmails(user , usersData) {
  try {
    const credentials = JSON.parse(fs.readFileSync('credentials.json'));
    const auth = await authorizesync(credentials, user.tokens);

    // Fetch the last synced historyId from the user data
    const lastSyncedHistoryId = user.messages[user.messages.length - 1].historyid;

    const messages = await listEmailssync(auth, lastSyncedHistoryId );
    console.log(messages);
    // Update the user's messages array and lastSyncedHistoryId
    user.messages = user.messages.concat(messages);
    //user.lastSyncedHistoryId = messages[messages.length - 1].historyId;

    // Write the updated data back to the users.json file
    fs.writeFileSync(USERS_JSON_PATH, JSON.stringify(usersData, null, 2));

    console.log('Email synchronization completed.');
  } catch (error) {
    console.error('Error in email synchronization:', error);
  }
}


const tokenUrl = 'https://oauth2.googleapis.com/token';

const refreshToken = (user , usersData) => {
  const credentials = JSON.parse(fs.readFileSync('credentials.json'));
  const { client_secret, client_id, redirect_uris } = credentials.installed;

  const formData = {
    client_id: client_id,
    client_secret: client_secret,
    refresh_token: user.tokens.refresh_token,
    grant_type: 'refresh_token'
  };

  request.post({ url: tokenUrl, form: formData }, (err, response, body) => {
    if (err) {
      console.error('Error refreshing token:', err);
      return;
    }

    const tokenResponse = JSON.parse(body);

    if (tokenResponse.error) {
      console.error('Error response from token endpoint:', tokenResponse.error);
      return;
    }

    const newAccessToken = tokenResponse.access_token;
    console.log(newAccessToken);
    user.tokens.access_token = newAccessToken;
    console.log('Access token refreshed successfully');
    // Use the new access token for your API requests
  });
};

cron.schedule('*/50 * * * *', () => {
  try {
    const usersData = JSON.parse(fs.readFileSync(USERS_JSON_PATH));

    for (const user of usersData.users) {
     refreshToken(user , usersData);
    }
  } catch (error) {
    console.error('Error:', error);
  }
});


cron.schedule('*/10 * * * * *', async () => {
  try {
    const usersData = JSON.parse(fs.readFileSync(USERS_JSON_PATH));

    for (const user of usersData.users) {
      syncEmails(user , usersData);
    }
  } catch (error) {
    console.error('Error:', error);
  }
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});


