const express = require('express');
const app = express();

const cron = require('node-cron');

//I every second
cron.schedule('*/10 * * * * *',function(){
    console.log('Cron running');
})

